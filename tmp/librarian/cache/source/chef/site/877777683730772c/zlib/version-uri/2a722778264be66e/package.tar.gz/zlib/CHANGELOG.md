## v2.0.0

* [COOK-1835] - use platform_family

## v1.0.2

* [COOK-1899] - add archlinux support
