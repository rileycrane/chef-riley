## v1.2.0:

* [COOK-2287] - Add support for installing Erlang from source

## v1.1.2:

* [COOK-1215] - Support Amazon Linux in erlang cookbook
* [COOK-1884] - Erlang Readme does not reflect cookbook requirements

## v1.1.0:

* [COOK-1782] - Add test kitchen support

## v1.0.0:

* [COOK-905] - Fix installation on RHEL/CentOS 6+
